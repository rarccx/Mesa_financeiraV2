"use strict"; if (window.top !== window.self) { document.body.replaceChildren(); throw new Error("Painel bloqueado em iframe"); }
