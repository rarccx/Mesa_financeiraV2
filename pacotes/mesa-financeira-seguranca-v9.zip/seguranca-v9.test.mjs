// Teste isolado (contas fictícias) das regras do seguranca-v9-instalacao.sql.
// Uso: npm i @electric-sql/pglite@0.5.11 && node seguranca-v9.test.mjs
import { PGlite } from "@electric-sql/pglite";
import { readFileSync } from "node:fs";
import assert from "node:assert/strict";

const dir = new URL(".", import.meta.url);
const db = new PGlite();
const A = "00000000-0000-0000-0000-00000000000a"; // admin
const B = "00000000-0000-0000-0000-00000000000b"; // cliente
const strip = (s) => s.replace(/^\s*(BEGIN|COMMIT);\s*$/gm, "");

await db.exec(`
CREATE ROLE anon; CREATE ROLE authenticated; CREATE ROLE service_role; CREATE ROLE supabase_auth_admin;
CREATE SCHEMA auth; CREATE SCHEMA storage;
CREATE TABLE auth.users(id uuid primary key, email text, email_confirmed_at timestamptz, last_sign_in_at timestamptz, raw_user_meta_data jsonb default '{}');
CREATE TABLE auth.identities(user_id uuid, provider text, identity_data jsonb);
CREATE TABLE storage.objects(id int); ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;
CREATE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql STABLE AS $$ select nullif(current_setting('t.uid',true),'')::uuid $$;
CREATE FUNCTION auth.jwt() RETURNS jsonb LANGUAGE sql STABLE AS $$ select coalesce(nullif(current_setting('t.jwt',true),''),'{}')::jsonb $$;
GRANT USAGE ON SCHEMA auth TO authenticated, supabase_auth_admin;
CREATE FUNCTION public.sou_admin() RETURNS boolean LANGUAGE sql STABLE AS $$ select auth.uid()='${A}'::uuid $$;
CREATE TABLE public.mesa_dados(user_id uuid, d jsonb); ALTER TABLE public.mesa_dados ENABLE ROW LEVEL SECURITY;
INSERT INTO auth.users VALUES('${A}','admin@x.com',now(),now()),('${B}','cli@x.com',now(),null);
INSERT INTO auth.identities VALUES('${B}','google','{"email":"cli@x.com","email_verified":"true"}');
`);
await db.exec(strip(readFileSync(new URL("google-acesso.sql", dir), "utf8")));
await db.exec(strip(readFileSync(new URL("seguranca-v9-instalacao.sql", dir), "utf8")));

async function como(uid, sql, { role = "authenticated", jwt = "" } = {}) {
  await db.exec(`RESET ROLE; SELECT set_config('t.uid','${uid ?? ""}',false); SELECT set_config('t.jwt','${jwt}',false); SET ROLE ${role};`);
  try { return (await db.query(sql)).rows; } finally { await db.exec("RESET ROLE"); }
}
const falha = async (p, re) => assert.match((await p.then(() => ({ message: "NÃO FALHOU" }), (e) => e)).message, re);
let ok = 0; const t = async (nome, fn) => { await fn(); ok++; console.log("ok -", nome); };

await t("cada cliente atual ganhou a própria empresa", async () => {
  const r = await db.query("select count(*)::int n from public.mf_empresa_membros");
  assert.equal(r.rows[0].n, 2);
});
await t("admin atual entra na tabela de papéis", async () => {
  await como(A, "select public.mf_papel_bootstrap()");
  const r = await db.query(`select papel from public.mf_papeis where user_id='${A}'`);
  assert.equal(r.rows[0].papel, "admin");
});
await t("cliente comum não vê o painel", () => falha(como(B, "select * from public.mf_painel_clientes()"), /Acesso negado/));
await t("cliente comum não lê a auditoria direto", async () => {
  const r = await como(B, "select count(*)::int n from public.mf_auditoria").catch((e) => e);
  assert.ok(r instanceof Error || r[0].n === 0);
});
await t("liberar Google fica registrado", async () => {
  await como(A, `select public.mf_google_admin_set('${B}',true)`);
  const r = await db.query("select acao,sucesso,email from public.mf_auditoria order by id desc limit 1");
  assert.deepEqual(r.rows[0], { acao: "google_liberar", sucesso: true, email: "cli@x.com" });
});
await t("login Google liberado é registrado como sucesso", async () => {
  const r = await como(null, `select public.mf_custom_access_token('{"user_id":"${B}","authentication_method":"oauth","claims":{}}') j`, { role: "supabase_auth_admin" });
  assert.equal(r[0].j.claims.mf_google_session, true);
  const a = await db.query(`select ator,alvo,email,acao,sucesso from public.mf_auditoria where acao='google_login' and sucesso`);
  assert.deepEqual(a.rows, [{ator:B,alvo:B,email:"cli@x.com",acao:"google_login",sucesso:true}]);
});
await t("Google de e-mail sem cadastro é bloqueado e registrado", async () => {
  const r = await como(null, `select public.mf_before_user_created('{"user":{"email":"Out@x.com","app_metadata":{"provider":"google"}}}') j`, { role: "supabase_auth_admin" });
  assert.equal(r[0].j.error.http_code, 403);
  const a = await db.query("select email,sucesso from public.mf_auditoria where acao='google_conta_nova'");
  assert.deepEqual(a.rows[0], { email: "out@x.com", sucesso: false });
});
await t("após revogar, renovação da sessão Google é negada e registrada", async () => {
  await como(A, `select public.mf_google_admin_set('${B}',false)`);
  const r = await como(null, `select public.mf_custom_access_token('{"user_id":"${B}","claims":{"mf_google_session":"true"}}') j`, { role: "supabase_auth_admin" });
  assert.equal(r[0].j.error.http_code, 403);
  const a = await db.query("select count(*)::int n from public.mf_auditoria where acao='google_login' and not sucesso");
  assert.equal(a.rows[0].n, 1);
});
await t("ligar MFA exige ter confirmado o código", () => falha(como(A, "select public.mf_config_mfa_set(true)"), /autenticador/));
await t("com MFA ligado, ação de admin sem código é bloqueada", async () => {
  await como(A, "select public.mf_config_mfa_set(true)", { jwt: '{"aal":"aal2"}' });
  await falha(como(A, `select public.mf_google_admin_set('${B}',true)`), /autenticador/);
  await como(A, `select public.mf_google_admin_set('${B}',true)`, { jwt: '{"aal":"aal2"}' });
  await como(A, "select public.mf_config_mfa_set(false)", { jwt: '{"aal":"aal2"}' });
});
await t("admin não remove o próprio papel de admin", () => falha(como(A, `select public.mf_papel_set('${A}','admin',false)`), /próprio/));
await t("gerente vê o painel mas não altera", async () => {
  await como(A, `select public.mf_papel_set('${B}','gerente',true)`);
  const r = await como(B, "select email from public.mf_painel_clientes()");
  assert.equal(r.length, 2);
  await falha(como(B, `select public.mf_google_admin_set('${A}',true)`), /Acesso negado/);
});
await t("gerente não altera papéis", async () => {
  await falha(como(B, `select public.mf_papel_set('${B}','admin',true)`), /Acesso negado/);
  assert.equal((await db.query(`select count(*)::int n from public.mf_papeis where user_id='${B}' and papel='admin'`)).rows[0].n, 0);
});
await t("MFA bloqueia alteração de papéis sem aal2", async () => {
  await como(A,"select public.mf_config_mfa_set(true)",{jwt:'{"aal":"aal2"}'});
  await falha(como(A,`select public.mf_papel_set('${B}','admin',true)`),/autenticador/);
  assert.equal((await db.query(`select count(*)::int n from public.mf_papeis where user_id='${B}' and papel='admin'`)).rows[0].n,0);
  await como(A,"select public.mf_config_mfa_set(false)",{jwt:'{"aal":"aal2"}'});
});
for (const fn of ["mf_painel_clientes()","mf_painel_auditoria(200)","mf_painel_config()","mf_google_admin_list()","mf_eh_gerente()","mf_eh_admin()","mf_papel_bootstrap()","mf_config_mfa_set(true)",`mf_papel_set('${B}','admin',true)`,`mf_google_admin_set('${B}',true)`]) {
 await t(`anon não executa ${fn.split('(')[0]}`,()=>falha(como(null,`select public.${fn}`,{role:"anon"}),/permission denied/));
}
await t("trigger cria empresa de novo usuário com isolamento",async()=>{
 const C="00000000-0000-0000-0000-00000000000c";
 await db.exec(`insert into auth.users(id,email,email_confirmed_at) values('${C}','novo@x.com',now())`);
 const rows=await como(C,"select e.nome,m.funcao from public.mf_empresas e join public.mf_empresa_membros m on m.empresa_id=e.id");
 assert.deepEqual(rows,[{nome:"Minha empresa",funcao:"dono"}]);
 assert.equal((await como(B,`select count(*)::int n from public.mf_empresa_membros where user_id='${C}'`))[0].n,0);
});
await t("limite: 30 alterações em 10 minutos", async () => {
  await db.exec(`insert into public.mf_auditoria(ator,acao,sucesso) select '${A}','google_liberar',true from generate_series(1,30)`);
  await falha(como(A, `select public.mf_google_admin_set('${B}',true)`), /Aguarde 10 minutos/);
});


await t("instalação: grants não permitem escrita direta por cliente", async () => {
 const r=await db.query("select has_table_privilege('authenticated','public.mf_papeis','INSERT') i,has_table_privilege('anon','public.mf_auditoria','SELECT') s");
 assert.deepEqual(r.rows[0],{i:false,s:false});
});
await db.exec("delete from public.mf_auditoria");
await t("30 alterações compartilhadas, 31ª negada",async()=>{
 for(let i=0;i<30;i++) await como(A, i%2 ? `select public.mf_papel_set('${B}','gerente',true)` : `select public.mf_google_admin_set('${B}',true)`);
 const r=await db.query(`select count(*)::int n from public.mf_auditoria where ator='${A}'`); assert.equal(r.rows[0].n,30);
 await falha(como(A,`select public.mf_google_admin_set('${B}',false)`),/Aguarde 10 minutos/);
 await falha(como(A,"select public.mf_config_mfa_set(true)",{jwt:'{"aal":"aal2"}'}),/Aguarde 10 minutos/);
});
await db.exec("delete from public.mf_auditoria; delete from public.mf_google_allowlist; delete from public.mf_papeis where papel='gerente'; CREATE FUNCTION public.fail_audit() RETURNS trigger LANGUAGE plpgsql AS $$BEGIN RAISE EXCEPTION 'audit indisponivel'; END$$; CREATE TRIGGER fail_audit BEFORE INSERT ON public.mf_auditoria FOR EACH ROW EXECUTE FUNCTION public.fail_audit();");
await t("falha na auditoria desfaz liberação Google",async()=>{
 await falha(como(A,`select public.mf_google_admin_set('${B}',true)`),/audit indisponivel/);
 const r=await db.query("select count(*)::int n from public.mf_google_allowlist"); assert.equal(r.rows[0].n,0);
});
await t("falha na auditoria desfaz alteração de papel",async()=>{
 await falha(como(A,`select public.mf_papel_set('${B}','gerente',true)`),/audit indisponivel/);
 const r=await db.query("select count(*)::int n from public.mf_papeis where papel='gerente'"); assert.equal(r.rows[0].n,0);
});
await t("falha na auditoria desfaz configuração MFA",async()=>{
 await falha(como(A,"select public.mf_config_mfa_set(true)",{jwt:'{"aal":"aal2"}'}),/audit indisponivel/);
 const r=await db.query("select valor from public.mf_config where chave='exigir_mfa_admin'"); assert.equal(r.rows[0].valor,false);
});
await t("falha no registro não muda rejeição no hook",async()=>{
 const r=await como(null,`select public.mf_before_user_created('{"user":{"email":"out@x.com","app_metadata":{"provider":"google"}}}') j`,{role:'supabase_auth_admin'});
 assert.equal(r[0].j.error.http_code,403);
});
await db.exec("DROP TRIGGER fail_audit ON public.mf_auditoria");
await t("recusa em transação desfeita perde registro: não promete persistência",async()=>{
 await db.exec("BEGIN");
 await como(null,`select public.mf_before_user_created('{"user":{"email":"rollback@x.com","app_metadata":{"provider":"google"}}}')`,{role:'supabase_auth_admin'});
 await db.exec("ROLLBACK");
 const r=await db.query("select count(*)::int n from public.mf_auditoria where email='rollback@x.com'"); assert.equal(r.rows[0].n,0);
});
await t("bloqueio repetido é deduplicado em dez minutos",async()=>{
 for(let i=0;i<2;i++) await como(null,`select public.mf_before_user_created('{"user":{"email":"out@x.com","app_metadata":{"provider":"google"}}}')`,{role:'supabase_auth_admin'});
 const r=await db.query("select count(*)::int n from public.mf_auditoria where email='out@x.com'"); assert.equal(r.rows[0].n,1);
});
await t("hook registra sucesso por senha",async()=>{
 await como(null,`select public.mf_custom_access_token('{"user_id":"${A}","authentication_method":"password","claims":{}}')`,{role:'supabase_auth_admin'});
 const r=await db.query("select sucesso from public.mf_auditoria where acao='login_senha'"); assert.equal(r.rows[0].sucesso,true);
});
await t("retenção remove só registros com mais de 180 dias",async()=>{
 await db.exec("insert into public.mf_auditoria(acao,sucesso,criado_em) values ('antigo',true,now()-interval '181 days'),('recente',true,now()-interval '179 days'); delete from public.mf_auditoria where criado_em<now()-interval '180 days'");
 const r=await db.query("select acao from public.mf_auditoria where acao in ('antigo','recente')"); assert.deepEqual(r.rows,[{acao:'recente'}]);
});
await t("atualização v8-v9 mantém dados e pode ser reaplicada",async()=>{
 const before=(await db.query("select count(*)::int n from public.mf_empresa_membros")).rows[0].n;
 for(let i=0;i<2;i++) await db.exec(strip(readFileSync(new URL('seguranca-v9-atualizar-v8.sql',dir),'utf8')));
 assert.equal((await db.query("select count(*)::int n from public.mf_empresa_membros")).rows[0].n,before);
 await falha(como(A,`select public.mf_registrar_admin('${A}',null,null,'inventado',true,'')`),/permission denied/);
});
console.log(`\n${ok} testes passaram`);
await db.close();
