-- Mesa Financeira v9: auditoria, papéis, empresas, limite de tentativas e MFA opcional.
-- Rode DEPOIS do google-acesso.sql (v6/v7) e com backup feito.
-- Não altera dados financeiros, senhas nem as políticas de cada cliente.
-- Instalação única: repetir dá erro e a transação inteira é desfeita.
BEGIN;
DO $$ BEGIN
 IF to_regprocedure('public.sou_admin()') IS NULL OR to_regprocedure('public.mf_google_authorized(uuid)') IS NULL THEN
  RAISE EXCEPTION 'Instale primeiro o google-acesso.sql (v6/v7).';
 END IF;
END $$;

-- ===== 1. Papéis em tabela própria =====
CREATE TYPE public.mf_papel AS ENUM ('admin','gerente');
CREATE TABLE public.mf_papeis (
 user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 papel public.mf_papel NOT NULL,
 concedido_por uuid REFERENCES auth.users(id) ON DELETE SET NULL,
 concedido_em timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY (user_id,papel)
);
REVOKE ALL ON public.mf_papeis FROM PUBLIC,anon,authenticated;
GRANT SELECT ON public.mf_papeis TO authenticated;
GRANT ALL ON public.mf_papeis TO service_role;
ALTER TABLE public.mf_papeis ENABLE ROW LEVEL SECURITY;
CREATE POLICY mf_papeis_read_own ON public.mf_papeis FOR SELECT TO authenticated USING (user_id=auth.uid());

CREATE FUNCTION public.mf_tem_papel(p_user uuid,p_papel public.mf_papel) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path='' AS $$
 SELECT EXISTS(SELECT 1 FROM public.mf_papeis WHERE user_id=p_user AND papel=p_papel);
$$;
REVOKE ALL ON FUNCTION public.mf_tem_papel(uuid,public.mf_papel) FROM PUBLIC,anon,authenticated;

-- Admin = sou_admin() atual OU papel admin na tabela nova (compatível com o que já existe).
CREATE FUNCTION public.mf_eh_admin() RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path='' AS $$
 SELECT auth.uid() IS NOT NULL AND (coalesce(public.sou_admin(),false) OR public.mf_tem_papel(auth.uid(),'admin'));
$$;
CREATE FUNCTION public.mf_eh_gerente() RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path='' AS $$
 SELECT public.mf_eh_admin() OR (auth.uid() IS NOT NULL AND public.mf_tem_papel(auth.uid(),'gerente'));
$$;
REVOKE ALL ON FUNCTION public.mf_eh_admin(),public.mf_eh_gerente() FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.mf_eh_admin(),public.mf_eh_gerente() TO authenticated;

-- ===== 2. Configuração (MFA opcional) =====
CREATE TABLE public.mf_config (
 chave text PRIMARY KEY,
 valor jsonb NOT NULL,
 alterado_em timestamptz NOT NULL DEFAULT now()
);
REVOKE ALL ON public.mf_config FROM PUBLIC,anon,authenticated;
GRANT ALL ON public.mf_config TO service_role;
ALTER TABLE public.mf_config ENABLE ROW LEVEL SECURITY;
INSERT INTO public.mf_config(chave,valor) VALUES ('exigir_mfa_admin','false'::jsonb);

-- Bloqueia ações de admin sem segundo fator quando a opção estiver ligada.
CREATE FUNCTION public.mf_exigir_admin() RETURNS void
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path='' AS $$
BEGIN
 IF NOT public.mf_eh_admin() THEN RAISE EXCEPTION 'Acesso negado' USING ERRCODE='42501'; END IF;
 IF coalesce((SELECT valor='true'::jsonb FROM public.mf_config WHERE chave='exigir_mfa_admin'),false)
    AND coalesce(auth.jwt()->>'aal','aal1')<>'aal2' THEN
  RAISE EXCEPTION 'Confirme o código do autenticador no Painel de Segurança para fazer esta ação.' USING ERRCODE='42501';
 END IF;
END $$;
REVOKE ALL ON FUNCTION public.mf_exigir_admin() FROM PUBLIC,anon,authenticated;

-- ===== 3. Registro de auditoria =====
CREATE TABLE public.mf_auditoria (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 criado_em timestamptz NOT NULL DEFAULT now(),
 ator uuid,
 alvo uuid,
 email text,
 acao text NOT NULL,
 sucesso boolean NOT NULL,
 motivo text NOT NULL DEFAULT ''
);
CREATE INDEX mf_auditoria_data_idx ON public.mf_auditoria(criado_em DESC);
CREATE INDEX mf_auditoria_ator_idx ON public.mf_auditoria(ator,acao,criado_em DESC);
REVOKE ALL ON public.mf_auditoria FROM PUBLIC,anon,authenticated;
GRANT ALL ON public.mf_auditoria TO service_role;
ALTER TABLE public.mf_auditoria ENABLE ROW LEVEL SECURITY;
-- Sem políticas: ninguém lê direto; só pelas funções do painel.

CREATE FUNCTION public.mf_registrar(p_ator uuid,p_alvo uuid,p_email text,p_acao text,p_sucesso boolean,p_motivo text) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
BEGIN
 -- Eventos recusados repetidos: no máximo um por e-mail/ação a cada 10 minutos.
 IF NOT p_sucesso THEN
  PERFORM pg_advisory_xact_lock(hashtextextended('mf-denial:'||lower(coalesce(p_email,''))||':'||p_acao,0));
  IF EXISTS(SELECT 1 FROM public.mf_auditoria WHERE email=left(lower(coalesce(p_email,'')),320)
   AND acao=left(p_acao,60) AND NOT sucesso AND criado_em>now()-interval '10 minutes') THEN RETURN; END IF;
 END IF;
 INSERT INTO public.mf_auditoria(ator,alvo,email,acao,sucesso,motivo)
 VALUES(p_ator,p_alvo,left(lower(coalesce(p_email,'')),320),left(p_acao,60),p_sucesso,left(coalesce(p_motivo,''),300));
EXCEPTION WHEN others THEN NULL; -- melhor esforço SOMENTE para hooks; recusas podem sofrer rollback no serviço Auth
END $$;
REVOKE ALL ON FUNCTION public.mf_registrar(uuid,uuid,text,text,boolean,text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.mf_registrar(uuid,uuid,text,text,boolean,text) TO supabase_auth_admin;

-- Escrita obrigatória: falha de auditoria desfaz a ação administrativa.
CREATE OR REPLACE FUNCTION public.mf_registrar_admin(p_ator uuid,p_alvo uuid,p_email text,p_acao text,p_sucesso boolean,p_motivo text) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
BEGIN
 INSERT INTO public.mf_auditoria(ator,alvo,email,acao,sucesso,motivo)
 VALUES(p_ator,p_alvo,left(lower(coalesce(p_email,'')),320),left(p_acao,60),p_sucesso,left(coalesce(p_motivo,''),300));
END $$;
REVOKE ALL ON FUNCTION public.mf_registrar_admin(uuid,uuid,text,text,boolean,text) FROM PUBLIC,anon,authenticated;

-- Um limite compartilhado: Google + papéis + configuração MFA.
-- O lock é por administrador e dura até o commit, evitando ultrapassagem concorrente.
CREATE OR REPLACE FUNCTION public.mf_limitar_admin() RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
BEGIN
 PERFORM pg_advisory_xact_lock(hashtextextended('mf-admin:'||auth.uid()::text,0));
 IF (SELECT count(*) FROM public.mf_auditoria WHERE ator=auth.uid() AND sucesso
  AND (acao IN ('google_liberar','google_revogar','mfa_exigir_ligar','mfa_exigir_desligar') OR acao LIKE 'papel_%')
  AND criado_em>now()-interval '10 minutes')>=30 THEN
  RAISE EXCEPTION 'Muitas alterações em pouco tempo. Aguarde 10 minutos.';
 END IF;
END $$;
REVOKE ALL ON FUNCTION public.mf_limitar_admin() FROM PUBLIC,anon,authenticated;

-- Hooks: mesma lógica da v6, agora registrando as negações.
CREATE OR REPLACE FUNCTION public.mf_before_user_created(event jsonb) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
BEGIN
 IF event->'user'->'app_metadata'->>'provider'='google'
    OR coalesce(event->'user'->'app_metadata'->'providers','[]'::jsonb) ? 'google' THEN
  PERFORM public.mf_registrar(NULL,NULL,event->'user'->>'email','google_conta_nova',false,'E-mail sem cadastro no sistema');
  RETURN jsonb_build_object('error',jsonb_build_object('http_code',403,'message','Acesso Google não autorizado. Solicite liberação ao administrador.'));
 END IF;
 RETURN '{}'::jsonb;
END $$;

CREATE OR REPLACE FUNCTION public.mf_custom_access_token(event jsonb) RETURNS jsonb
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path='' AS $$
DECLARE claims jsonb:=event->'claims'; google_session boolean; v_user uuid:=(event->>'user_id')::uuid; v_novo boolean;
BEGIN
 v_novo:=event->>'authentication_method'='oauth';
 google_session:=coalesce((claims->>'mf_google_session')='true',false) OR v_novo
   OR EXISTS(SELECT 1 FROM jsonb_array_elements(coalesce(claims->'amr','[]'::jsonb)) a WHERE a->>'method'='oauth');
 IF google_session AND NOT public.mf_google_authorized(v_user) THEN
  PERFORM public.mf_registrar(v_user,v_user,(SELECT email FROM auth.users WHERE id=v_user),'google_login',false,'E-mail não liberado ou liberação revogada');
  RETURN jsonb_build_object('error',jsonb_build_object('http_code',403,'message','Acesso Google não autorizado. Solicite liberação ao administrador.'));
 END IF;
 IF event->>'authentication_method' IN ('password','totp') THEN
  PERFORM public.mf_registrar(v_user,v_user,(SELECT email FROM auth.users WHERE id=v_user),
   CASE WHEN event->>'authentication_method'='password' THEN 'login_senha' ELSE 'mfa_confirmado' END,true,'Evento de autenticação; não identifica qual página foi usada');
 END IF;
 IF v_novo THEN -- só no login, não em cada renovação
  PERFORM public.mf_registrar(v_user,v_user,(SELECT email FROM auth.users WHERE id=v_user),'google_login',true,'');
 END IF;
 claims:=jsonb_set(claims,'{mf_google_session}',to_jsonb(coalesce(google_session,false)),true);
 RETURN jsonb_build_object('claims',claims);
END $$;

-- Liberação Google: agora com auditoria, limite de tentativas e MFA opcional.
CREATE OR REPLACE FUNCTION public.mf_google_admin_set(p_user uuid,p_enabled boolean) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_email text;
BEGIN
 PERFORM public.mf_exigir_admin();
 PERFORM public.mf_limitar_admin();
 SELECT lower(btrim(u.email)) INTO v_email FROM auth.users u WHERE u.id=p_user;
 IF p_enabled THEN
  IF v_email IS NULL OR v_email='' OR NOT EXISTS(SELECT 1 FROM auth.users WHERE id=p_user AND email_confirmed_at IS NOT NULL) THEN
   RAISE EXCEPTION 'Cliente inexistente ou e-mail ainda não confirmado';
  END IF;
  INSERT INTO public.mf_google_allowlist(user_id,email,authorized_by) VALUES(p_user,v_email,auth.uid())
  ON CONFLICT(user_id) DO UPDATE SET email=excluded.email,authorized_by=excluded.authorized_by,authorized_at=now();
 ELSE DELETE FROM public.mf_google_allowlist WHERE user_id=p_user;
 END IF;
 PERFORM public.mf_registrar_admin(auth.uid(),p_user,v_email,CASE WHEN p_enabled THEN 'google_liberar' ELSE 'google_revogar' END,true,'');
END $$;

CREATE OR REPLACE FUNCTION public.mf_google_admin_list() RETURNS TABLE(user_id uuid,email text)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path='' AS $$
BEGIN
 IF NOT public.mf_eh_gerente() THEN RAISE EXCEPTION 'Acesso negado' USING ERRCODE='42501'; END IF;
 RETURN QUERY SELECT a.user_id,a.email FROM public.mf_google_allowlist a;
END $$;

-- ===== 4. Empresas (preparação para várias empresas por cliente) =====
CREATE TABLE public.mf_empresas (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 nome text NOT NULL CHECK (length(btrim(nome)) BETWEEN 1 AND 120),
 criado_em timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.mf_empresa_membros (
 empresa_id uuid NOT NULL REFERENCES public.mf_empresas(id) ON DELETE CASCADE,
 user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 funcao text NOT NULL DEFAULT 'dono' CHECK (funcao IN ('dono','membro')),
 PRIMARY KEY (empresa_id,user_id)
);
REVOKE ALL ON public.mf_empresas,public.mf_empresa_membros FROM PUBLIC,anon,authenticated;
GRANT SELECT ON public.mf_empresas,public.mf_empresa_membros TO authenticated;
GRANT ALL ON public.mf_empresas,public.mf_empresa_membros TO service_role;
ALTER TABLE public.mf_empresas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mf_empresa_membros ENABLE ROW LEVEL SECURITY;
CREATE POLICY mf_membros_read_own ON public.mf_empresa_membros FOR SELECT TO authenticated USING (user_id=auth.uid());
CREATE POLICY mf_empresas_read_member ON public.mf_empresas FOR SELECT TO authenticated
 USING (EXISTS(SELECT 1 FROM public.mf_empresa_membros m WHERE m.empresa_id=id AND m.user_id=auth.uid()));

-- Cada cliente atual vira dono da própria empresa (nada muda nos dados financeiros).
CREATE FUNCTION public.mf_criar_empresa_padrao(p_user uuid,p_email text) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_id uuid;
BEGIN
 IF EXISTS(SELECT 1 FROM public.mf_empresa_membros WHERE user_id=p_user) THEN RETURN; END IF;
 INSERT INTO public.mf_empresas(nome) VALUES('Minha empresa') RETURNING id INTO v_id;
 INSERT INTO public.mf_empresa_membros(empresa_id,user_id,funcao) VALUES(v_id,p_user,'dono');
END $$;
REVOKE ALL ON FUNCTION public.mf_criar_empresa_padrao(uuid,text) FROM PUBLIC,anon,authenticated;
CREATE FUNCTION public.mf_empresa_signup() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
BEGIN
 BEGIN PERFORM public.mf_criar_empresa_padrao(NEW.id,NEW.email); EXCEPTION WHEN others THEN NULL; END;
 RETURN NEW;
END $$;
REVOKE ALL ON FUNCTION public.mf_empresa_signup() FROM PUBLIC,anon,authenticated;
CREATE TRIGGER mf_empresa_signup AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.mf_empresa_signup();
DO $$ DECLARE u record; BEGIN
 FOR u IN SELECT id,email FROM auth.users LOOP PERFORM public.mf_criar_empresa_padrao(u.id,u.email); END LOOP;
END $$;

-- Guarda de sessão Google também nas tabelas novas (como na v6).
DO $$ DECLARE t text; BEGIN
 FOREACH t IN ARRAY ARRAY['mf_papeis','mf_config','mf_auditoria','mf_empresas','mf_empresa_membros'] LOOP
  EXECUTE format('CREATE POLICY mf_google_session_guard ON public.%I AS RESTRICTIVE FOR ALL TO authenticated USING (public.mf_session_allowed()) WITH CHECK (public.mf_session_allowed())',t);
 END LOOP;
END $$;

-- ===== 5. Funções do Painel de Segurança =====
CREATE FUNCTION public.mf_painel_clientes() RETURNS TABLE(user_id uuid,email text,ultimo_acesso timestamptz,google boolean,papeis text[],empresas text[])
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path='' AS $$
BEGIN
 IF NOT public.mf_eh_gerente() THEN RAISE EXCEPTION 'Acesso negado' USING ERRCODE='42501'; END IF;
 RETURN QUERY
 SELECT u.id,u.email::text,u.last_sign_in_at,
  EXISTS(SELECT 1 FROM public.mf_google_allowlist a WHERE a.user_id=u.id),
  coalesce((SELECT array_agg(p.papel::text ORDER BY p.papel) FROM public.mf_papeis p WHERE p.user_id=u.id),'{}'),
  coalesce((SELECT array_agg(e.nome ORDER BY e.nome) FROM public.mf_empresa_membros m JOIN public.mf_empresas e ON e.id=m.empresa_id WHERE m.user_id=u.id),'{}')
 FROM auth.users u ORDER BY u.email;
END $$;

CREATE FUNCTION public.mf_painel_auditoria(p_limite int DEFAULT 200) RETURNS SETOF public.mf_auditoria
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path='' AS $$
BEGIN
 IF NOT public.mf_eh_gerente() THEN RAISE EXCEPTION 'Acesso negado' USING ERRCODE='42501'; END IF;
 RETURN QUERY SELECT * FROM public.mf_auditoria ORDER BY criado_em DESC LIMIT least(greatest(coalesce(p_limite,200),1),1000);
END $$;

CREATE FUNCTION public.mf_painel_config() RETURNS jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path='' AS $$
BEGIN
 IF NOT public.mf_eh_gerente() THEN RAISE EXCEPTION 'Acesso negado' USING ERRCODE='42501'; END IF;
 RETURN jsonb_build_object(
  'exigir_mfa_admin',coalesce((SELECT valor='true'::jsonb FROM public.mf_config WHERE chave='exigir_mfa_admin'),false),
  'sou_admin',public.mf_eh_admin(),
  'aal',coalesce(auth.jwt()->>'aal','aal1'));
END $$;

CREATE FUNCTION public.mf_config_mfa_set(p_ativo boolean) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
BEGIN
 IF NOT public.mf_eh_admin() THEN RAISE EXCEPTION 'Acesso negado' USING ERRCODE='42501'; END IF;
 -- Só liga/desliga quem já confirmou o segundo fator nesta sessão (evita se trancar fora).
 IF coalesce(auth.jwt()->>'aal','aal1')<>'aal2' THEN
  RAISE EXCEPTION 'Confirme o código do autenticador antes de alterar esta opção.' USING ERRCODE='42501';
 END IF;
 PERFORM public.mf_limitar_admin();
 UPDATE public.mf_config SET valor=to_jsonb(p_ativo),alterado_em=now() WHERE chave='exigir_mfa_admin';
 PERFORM public.mf_registrar_admin(auth.uid(),NULL,NULL,CASE WHEN p_ativo THEN 'mfa_exigir_ligar' ELSE 'mfa_exigir_desligar' END,true,'');
END $$;

CREATE FUNCTION public.mf_papel_set(p_user uuid,p_papel public.mf_papel,p_ativo boolean) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_email text;
BEGIN
 PERFORM public.mf_exigir_admin();
 PERFORM public.mf_limitar_admin();
 IF p_user=auth.uid() AND p_papel='admin' AND NOT p_ativo THEN
  RAISE EXCEPTION 'Você não pode remover o seu próprio papel de administrador.';
 END IF;
 SELECT email INTO v_email FROM auth.users WHERE id=p_user;
 IF v_email IS NULL THEN RAISE EXCEPTION 'Usuário inexistente'; END IF;
 IF p_ativo THEN
  INSERT INTO public.mf_papeis(user_id,papel,concedido_por) VALUES(p_user,p_papel,auth.uid()) ON CONFLICT DO NOTHING;
 ELSE DELETE FROM public.mf_papeis WHERE user_id=p_user AND papel=p_papel;
 END IF;
 PERFORM public.mf_registrar_admin(auth.uid(),p_user,v_email,'papel_'||p_papel::text||CASE WHEN p_ativo THEN '_dar' ELSE '_tirar' END,true,'');
END $$;

REVOKE ALL ON FUNCTION public.mf_painel_clientes(),public.mf_painel_auditoria(int),public.mf_painel_config(),
 public.mf_config_mfa_set(boolean),public.mf_papel_set(uuid,public.mf_papel,boolean) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.mf_painel_clientes(),public.mf_painel_auditoria(int),public.mf_painel_config(),
 public.mf_config_mfa_set(boolean),public.mf_papel_set(uuid,public.mf_papel,boolean) TO authenticated;

-- O próprio administrador atual (sou_admin) entra na tabela de papéis no primeiro acesso ao painel.
CREATE FUNCTION public.mf_papel_bootstrap() RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
BEGIN
 IF auth.uid() IS NOT NULL AND coalesce(public.sou_admin(),false) THEN
  INSERT INTO public.mf_papeis(user_id,papel) VALUES(auth.uid(),'admin') ON CONFLICT DO NOTHING;
 END IF;
END $$;
REVOKE ALL ON FUNCTION public.mf_papel_bootstrap() FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.mf_papel_bootstrap() TO authenticated;
COMMIT;
