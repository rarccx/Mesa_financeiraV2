-- Opcional: execute só depois de habilitar pg_cron no serviço externo.
-- 1 vez por dia às 03:00 UTC; retenção de 180 dias (não altera dados financeiros).
SELECT cron.schedule('mf-auditoria-retencao-180d','0 3 * * *',
 $$DELETE FROM public.mf_auditoria WHERE criado_em < now()-interval '180 days';$$);
-- Sem pg_cron, execute manualmente a instrução DELETE acima periodicamente.
