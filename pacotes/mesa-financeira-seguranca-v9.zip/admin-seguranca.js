// Painel de Segurança (v9). Toda permissão é verificada no banco; esta tela só exibe.
(function () {
  "use strict";
  if (window.top !== window.self) { document.body.replaceChildren(); return; }
  const CF = window.MF_CONFIG || {};
  const $ = (id) => document.getElementById(id);
  const aviso = (t, bom) => { $("aviso").textContent = t || ""; $("aviso").className = bom ? "bom" : ""; };
  if (!window.supabase || !CF.SB_URL || !CF.SB_KEY) { aviso("Configuração ausente: confira o config.js."); return; }
  const sb = window.supabase.createClient(CF.SB_URL, CF.SB_KEY, { auth: { persistSession: false, autoRefreshToken: true, detectSessionInUrl: false } });

  const ACOES = {
    login_senha: "Login com senha", mfa_confirmado: "MFA confirmado",
    google_liberar: "Google liberado", google_revogar: "Google removido",
    google_login: "Login com Google", google_conta_nova: "Google sem cadastro",
    mfa_exigir_ligar: "MFA passou a ser exigido", mfa_exigir_desligar: "MFA deixou de ser exigido",
    papel_admin_dar: "Virou admin", papel_admin_tirar: "Deixou de ser admin",
    papel_gerente_dar: "Virou gerente", papel_gerente_tirar: "Deixou de ser gerente",
  };
  let CFG = { sou_admin: false, exigir_mfa_admin: false, aal: "aal1" };
  let fatorPendente = null;

  const mostrar = (tela) => ["telaLogin", "telaMfa", "telaPainel"].forEach((t) => ($(t).hidden = t !== tela));
  const data = (s) => (s ? new Date(s).toLocaleString("pt-BR") : "—");
  function td(texto, cls) { const c = document.createElement("td"); c.textContent = texto; if (cls) c.className = cls; return c; }
  function caixa(marcado, habilitado, rotulo, onChange) {
    const c = document.createElement("td"); const i = document.createElement("input");
    i.type = "checkbox"; i.checked = marcado; i.disabled = !habilitado; i.style.width = "auto"; i.style.margin = "0";
    i.setAttribute("aria-label", rotulo);
    i.addEventListener("change", async () => { i.disabled = true; const ok = await onChange(i.checked); if (!ok) i.checked = !i.checked; i.disabled = false; });
    c.appendChild(i); return c;
  }
  const rpc = async (nome, args) => {
    const r = await sb.rpc(nome, args);
    if (r.error) { aviso(r.error.message); return null; }
    return r.data ?? true;
  };

  async function depoisDoLogin() {
    const ger = await sb.rpc("mf_eh_gerente");
    if (ger.error || ger.data !== true) { await sb.auth.signOut(); mostrar("telaLogin"); aviso("Esta conta não tem acesso ao painel."); return; }
    await sb.rpc("mf_papel_bootstrap");
    const { data: aal } = await sb.auth.mfa.getAuthenticatorAssuranceLevel();
    if (aal && aal.nextLevel === "aal2" && aal.currentLevel !== "aal2") {
      const { data: f } = await sb.auth.mfa.listFactors();
      fatorPendente = f && f.totp && f.totp[0];
      if (fatorPendente) { mostrar("telaMfa"); $("codigo").focus(); return; }
    }
    await carregar();
  }

  async function carregar() {
    mostrar("telaPainel");
    const { data: u } = await sb.auth.getUser();
    const c = await rpc("mf_painel_config"); if (!c) return; CFG = c;
    $("quem").textContent = (u.user ? u.user.email : "") + (CFG.sou_admin ? " · administrador" : " · gerente (somente leitura)");
    const { data: f } = await sb.auth.mfa.listFactors();
    const temFator = !!(f && f.totp && f.totp.length);
    $("mfaStatus").textContent =
      (temFator ? "Autenticador cadastrado nesta conta. " : "Nenhum autenticador cadastrado. ") +
      (CFG.exigir_mfa_admin ? "O código é EXIGIDO para ações de admin." : "O código ainda não é exigido.");
    $("btCadastrarMfa").hidden = temFator;
    $("btExigirMfa").hidden = !(CFG.sou_admin && temFator);
    $("btExigirMfa").textContent = CFG.exigir_mfa_admin ? "Deixar de exigir o código" : "Passar a exigir o código";

    const lista = (await rpc("mf_painel_clientes")) || [];
    const tb = $("tbClientes"); tb.replaceChildren();
    lista.forEach((x) => {
      const tr = document.createElement("tr"); const papeis = x.papeis || [];
      tr.append(td(x.email), td((x.empresas || []).join(", ") || "—"), td(data(x.ultimo_acesso)));
      tr.append(caixa(x.google, CFG.sou_admin, "Google liberado para " + x.email, async (v) => {
        const ok = await rpc("mf_google_admin_set", { p_user: x.user_id, p_enabled: v });
        if (ok) { aviso(v ? "Google liberado para " + x.email : "Google removido de " + x.email, true); carregarAuditoria(); }
        return !!ok;
      }));
      ["gerente", "admin"].forEach((p) => tr.append(caixa(papeis.includes(p), CFG.sou_admin, p + " — " + x.email, async (v) => {
        const ok = await rpc("mf_papel_set", { p_user: x.user_id, p_papel: p, p_ativo: v });
        if (ok) { aviso("Papel atualizado.", true); carregarAuditoria(); }
        return !!ok;
      })));
      tb.appendChild(tr);
    });
    await carregarAuditoria();
  }

  async function carregarAuditoria() {
    const lista = (await rpc("mf_painel_auditoria", { p_limite: 200 })) || [];
    const tb = $("tbAuditoria"); tb.replaceChildren();
    if (!lista.length) { const tr = document.createElement("tr"); const c = td("Nenhum registro ainda."); c.colSpan = 5; tr.appendChild(c); tb.appendChild(tr); return; }
    lista.forEach((r) => {
      const tr = document.createElement("tr");
      tr.append(td(data(r.criado_em)), td(ACOES[r.acao] || r.acao), td(r.email || "—"),
        td(r.sucesso ? "Permitido" : "Bloqueado", r.sucesso ? "ok" : "no"), td(r.motivo || ""));
      tb.appendChild(tr);
    });
  }

  $("fLogin").addEventListener("submit", async (e) => {
    e.preventDefault(); aviso("");
    const { error } = await sb.auth.signInWithPassword({ email: $("email").value.trim(), password: $("senha").value });
    $("senha").value = "";
    if (error) { aviso("E-mail ou senha inválidos."); return; }
    depoisDoLogin();
  });

  $("fMfa").addEventListener("submit", async (e) => {
    e.preventDefault();
    if (!fatorPendente) { aviso("Inicie a confirmação do autenticador novamente."); return; }
    const { error } = await sb.auth.mfa.challengeAndVerify({ factorId: fatorPendente.id, code: $("codigo").value.trim() });
    $("codigo").value = "";
    if (error) { aviso("Código inválido. Tente de novo."); return; }
    aviso(""); carregar();
  });

  $("btCadastrarMfa").addEventListener("click", async () => {
    const { data: f } = await sb.auth.mfa.listFactors();
    for (const x of (f && f.all) || []) if (x.status === "unverified") await sb.auth.mfa.unenroll({ factorId: x.id });
    const { data, error } = await sb.auth.mfa.enroll({ factorType: "totp", friendlyName: "Mesa Financeira" });
    if (error) { aviso("Não foi possível iniciar o cadastro: " + error.message); return; }
    fatorPendente = data;
    $("mfaQr").src = data.totp.qr_code; $("mfaSegredo").textContent = data.totp.secret;
    $("mfaCadastro").hidden = false;
  });

  $("fMfaCadastro").addEventListener("submit", async (e) => {
    e.preventDefault();
    if (!fatorPendente) { aviso("Inicie a confirmação do autenticador novamente."); return; }
    const { error } = await sb.auth.mfa.challengeAndVerify({ factorId: fatorPendente.id, code: $("codigoCadastro").value.trim() });
    $("codigoCadastro").value = "";
    if (error) { aviso("Código inválido. Tente de novo."); return; }
    $("mfaCadastro").hidden = true; aviso("Autenticador ativado.", true); carregar();
  });

  $("btExigirMfa").addEventListener("click", async () => {
    const ok = await rpc("mf_config_mfa_set", { p_ativo: !CFG.exigir_mfa_admin });
    if (ok) { aviso("Opção atualizada.", true); carregar(); }
  });

  $("btAtualizar").addEventListener("click", () => carregar());
  $("btSair").addEventListener("click", async () => { await sb.auth.signOut(); mostrar("telaLogin"); aviso(""); });
})();
