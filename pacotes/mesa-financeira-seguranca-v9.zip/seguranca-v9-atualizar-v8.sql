-- SOMENTE para quem já instalou v8. Não execute junto da instalação completa v9.
BEGIN;
DO $$ BEGIN IF to_regclass('public.mf_config') IS NULL THEN RAISE EXCEPTION 'v8 não instalado: use a instalação completa v9.'; END IF; END $$;
CREATE OR REPLACE FUNCTION public.mf_registrar(p_ator uuid,p_alvo uuid,p_email text,p_acao text,p_sucesso boolean,p_motivo text) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
BEGIN
 -- Eventos recusados repetidos: no máximo um por e-mail/ação a cada 10 minutos.
 IF NOT p_sucesso THEN
  PERFORM pg_advisory_xact_lock(hashtextextended('mf-denial:'||lower(coalesce(p_email,''))||':'||p_acao,0));
  IF EXISTS(SELECT 1 FROM public.mf_auditoria WHERE email=left(lower(coalesce(p_email,'')),320)
   AND acao=left(p_acao,60) AND NOT sucesso AND criado_em>now()-interval '10 minutes') THEN RETURN; END IF;
 END IF;
 INSERT INTO public.mf_auditoria(ator,alvo,email,acao,sucesso,motivo)
 VALUES(p_ator,p_alvo,left(lower(coalesce(p_email,'')),320),left(p_acao,60),p_sucesso,left(coalesce(p_motivo,''),300));
EXCEPTION WHEN others THEN NULL; -- melhor esforço SOMENTE para hooks; recusas podem sofrer rollback no serviço Auth
END $$;

CREATE OR REPLACE FUNCTION public.mf_registrar_admin(p_ator uuid,p_alvo uuid,p_email text,p_acao text,p_sucesso boolean,p_motivo text) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
BEGIN
 INSERT INTO public.mf_auditoria(ator,alvo,email,acao,sucesso,motivo)
 VALUES(p_ator,p_alvo,left(lower(coalesce(p_email,'')),320),left(p_acao,60),p_sucesso,left(coalesce(p_motivo,''),300));
END $$;

CREATE OR REPLACE FUNCTION public.mf_limitar_admin() RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
BEGIN
 PERFORM pg_advisory_xact_lock(hashtextextended('mf-admin:'||auth.uid()::text,0));
 IF (SELECT count(*) FROM public.mf_auditoria WHERE ator=auth.uid() AND sucesso
  AND (acao IN ('google_liberar','google_revogar','mfa_exigir_ligar','mfa_exigir_desligar') OR acao LIKE 'papel_%')
  AND criado_em>now()-interval '10 minutes')>=30 THEN
  RAISE EXCEPTION 'Muitas alterações em pouco tempo. Aguarde 10 minutos.';
 END IF;
END $$;

CREATE OR REPLACE FUNCTION public.mf_custom_access_token(event jsonb) RETURNS jsonb
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path='' AS $$
DECLARE claims jsonb:=event->'claims'; google_session boolean; v_user uuid:=(event->>'user_id')::uuid; v_novo boolean;
BEGIN
 v_novo:=event->>'authentication_method'='oauth';
 google_session:=coalesce((claims->>'mf_google_session')='true',false) OR v_novo
   OR EXISTS(SELECT 1 FROM jsonb_array_elements(coalesce(claims->'amr','[]'::jsonb)) a WHERE a->>'method'='oauth');
 IF google_session AND NOT public.mf_google_authorized(v_user) THEN
  PERFORM public.mf_registrar(v_user,v_user,(SELECT email FROM auth.users WHERE id=v_user),'google_login',false,'E-mail não liberado ou liberação revogada');
  RETURN jsonb_build_object('error',jsonb_build_object('http_code',403,'message','Acesso Google não autorizado. Solicite liberação ao administrador.'));
 END IF;
 IF event->>'authentication_method' IN ('password','totp') THEN
  PERFORM public.mf_registrar(v_user,v_user,(SELECT email FROM auth.users WHERE id=v_user),
   CASE WHEN event->>'authentication_method'='password' THEN 'login_senha' ELSE 'mfa_confirmado' END,true,'Evento de autenticação; não identifica qual página foi usada');
 END IF;
 IF v_novo THEN -- só no login, não em cada renovação
  PERFORM public.mf_registrar(v_user,v_user,(SELECT email FROM auth.users WHERE id=v_user),'google_login',true,'');
 END IF;
 claims:=jsonb_set(claims,'{mf_google_session}',to_jsonb(coalesce(google_session,false)),true);
 RETURN jsonb_build_object('claims',claims);
END $$;

CREATE OR REPLACE FUNCTION public.mf_google_admin_set(p_user uuid,p_enabled boolean) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_email text;
BEGIN
 PERFORM public.mf_exigir_admin();
 PERFORM public.mf_limitar_admin();
 SELECT lower(btrim(u.email)) INTO v_email FROM auth.users u WHERE u.id=p_user;
 IF p_enabled THEN
  IF v_email IS NULL OR v_email='' OR NOT EXISTS(SELECT 1 FROM auth.users WHERE id=p_user AND email_confirmed_at IS NOT NULL) THEN
   RAISE EXCEPTION 'Cliente inexistente ou e-mail ainda não confirmado';
  END IF;
  INSERT INTO public.mf_google_allowlist(user_id,email,authorized_by) VALUES(p_user,v_email,auth.uid())
  ON CONFLICT(user_id) DO UPDATE SET email=excluded.email,authorized_by=excluded.authorized_by,authorized_at=now();
 ELSE DELETE FROM public.mf_google_allowlist WHERE user_id=p_user;
 END IF;
 PERFORM public.mf_registrar_admin(auth.uid(),p_user,v_email,CASE WHEN p_enabled THEN 'google_liberar' ELSE 'google_revogar' END,true,'');
END $$;

CREATE OR REPLACE FUNCTION public.mf_config_mfa_set(p_ativo boolean) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
BEGIN
 IF NOT public.mf_eh_admin() THEN RAISE EXCEPTION 'Acesso negado' USING ERRCODE='42501'; END IF;
 -- Só liga/desliga quem já confirmou o segundo fator nesta sessão (evita se trancar fora).
 IF coalesce(auth.jwt()->>'aal','aal1')<>'aal2' THEN
  RAISE EXCEPTION 'Confirme o código do autenticador antes de alterar esta opção.' USING ERRCODE='42501';
 END IF;
 PERFORM public.mf_limitar_admin();
 UPDATE public.mf_config SET valor=to_jsonb(p_ativo),alterado_em=now() WHERE chave='exigir_mfa_admin';
 PERFORM public.mf_registrar_admin(auth.uid(),NULL,NULL,CASE WHEN p_ativo THEN 'mfa_exigir_ligar' ELSE 'mfa_exigir_desligar' END,true,'');
END $$;

CREATE OR REPLACE FUNCTION public.mf_papel_set(p_user uuid,p_papel public.mf_papel,p_ativo boolean) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_email text;
BEGIN
 PERFORM public.mf_exigir_admin();
 PERFORM public.mf_limitar_admin();
 IF p_user=auth.uid() AND p_papel='admin' AND NOT p_ativo THEN
  RAISE EXCEPTION 'Você não pode remover o seu próprio papel de administrador.';
 END IF;
 SELECT email INTO v_email FROM auth.users WHERE id=p_user;
 IF v_email IS NULL THEN RAISE EXCEPTION 'Usuário inexistente'; END IF;
 IF p_ativo THEN
  INSERT INTO public.mf_papeis(user_id,papel,concedido_por) VALUES(p_user,p_papel,auth.uid()) ON CONFLICT DO NOTHING;
 ELSE DELETE FROM public.mf_papeis WHERE user_id=p_user AND papel=p_papel;
 END IF;
 PERFORM public.mf_registrar_admin(auth.uid(),p_user,v_email,'papel_'||p_papel::text||CASE WHEN p_ativo THEN '_dar' ELSE '_tirar' END,true,'');
END $$;

CREATE OR REPLACE FUNCTION public.mf_criar_empresa_padrao(p_user uuid,p_email text) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_id uuid;
BEGIN
 IF EXISTS(SELECT 1 FROM public.mf_empresa_membros WHERE user_id=p_user) THEN RETURN; END IF;
 INSERT INTO public.mf_empresas(nome) VALUES('Minha empresa') RETURNING id INTO v_id;
 INSERT INTO public.mf_empresa_membros(empresa_id,user_id,funcao) VALUES(v_id,p_user,'dono');
END $$;
REVOKE ALL ON public.mf_papeis,public.mf_config,public.mf_auditoria,public.mf_empresas,public.mf_empresa_membros FROM PUBLIC,anon,authenticated;
GRANT SELECT ON public.mf_papeis,public.mf_empresas,public.mf_empresa_membros TO authenticated;
GRANT ALL ON public.mf_papeis,public.mf_config,public.mf_auditoria,public.mf_empresas,public.mf_empresa_membros TO service_role;
REVOKE ALL ON FUNCTION public.mf_registrar_admin(uuid,uuid,text,text,boolean,text),public.mf_limitar_admin() FROM PUBLIC,anon,authenticated;
COMMIT;
